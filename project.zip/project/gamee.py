import pygame
import sys
import os
import math
import random
pygame.init()
pygame.mixer.init()
WIDTH, HEIGHT = 800, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Forest Cat")
clock = pygame.time.Clock()
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
GROUND_Y = 291

cat_skins = [
    ("cat1.png", "cat2.png"),
    ("cat1_black.png", "cat2_black.png"),
    ("cat1_red.png", "cat2_red.png")
]

#Фон
class Background:
    def __init__(self):
        self.image1 = pygame.image.load(os.path.join(BASE_DIR, "bg.png")).convert()
        self.image1 = pygame.transform.scale(self.image1, (WIDTH, HEIGHT))
        
        self.image2 = pygame.image.load(os.path.join(BASE_DIR, "back3.jpg")).convert()
        self.image2 = pygame.transform.scale(self.image2, (WIDTH, HEIGHT))

        self.image3 = pygame.image.load(os.path.join(BASE_DIR, "back33.jpg")).convert()
        self.image3 = pygame.transform.scale(self.image3, (WIDTH, HEIGHT))

        self.image4 = pygame.image.load(os.path.join(BASE_DIR, "back4.jpg")).convert()
        self.image4 = pygame.transform.scale(self.image4, (WIDTH, HEIGHT))

        self.image5 = pygame.image.load(os.path.join(BASE_DIR, "back5.jpg")).convert()
        self.image5 = pygame.transform.scale(self.image5, (WIDTH, HEIGHT))

        self.image6 = pygame.image.load(os.path.join(BASE_DIR, "back6.jpg")).convert()
        self.image6 = pygame.transform.scale(self.image6, (WIDTH, HEIGHT))

        self.image7 = pygame.image.load(os.path.join(BASE_DIR, "back7.jpg")).convert()
        self.image7 = pygame.transform.scale(self.image7, (WIDTH, HEIGHT))

        self.image8 = pygame.image.load(os.path.join(BASE_DIR, "back8.jpg")).convert()
        self.image8 = pygame.transform.scale(self.image8, (WIDTH, HEIGHT))

        self.image9 = pygame.image.load(os.path.join(BASE_DIR, "back9.jpg")).convert()
        self.image9 = pygame.transform.scale(self.image9, (WIDTH, HEIGHT))
        
    def draw(self, screen, player):
        if player.x < WIDTH:
            screen.blit(self.image1, (0,0))
        else:
            screen.blit(self.image2, (0,0))
#Платформы
class Platform:
    def __init__(self, x, y, image):
        self.image = image
        self.x = x
        self.y = y
        
    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y))
#Предмет
class Item:
    def __init__(self, x, y, image):
        self.image = image
        self.x = x
        self.y = y
        self.rect = self.image.get_rect(topleft=(x, y))
        self.collected = False
        self.base_y = y
        self.frame = random.randint(0,100)
        
    def update(self):
        self.frame += 1
        self.y = self.base_y + math.sin(self.frame * 0.06) * 4
        self.rect.y = self.y
        
    def draw(self, screen):
        if not self.collected:
            screen.blit(self.image, (self.x, self.y))
#Игрок
class Player:
    def __init__(self, skin_id=0):
        img1_path, img2_path = cat_skins[skin_id]
        
        self.image1 = pygame.image.load(os.path.join(BASE_DIR, img1_path)).convert_alpha()
        self.image2 = pygame.image.load(os.path.join(BASE_DIR, img2_path)).convert_alpha()
        
        self.image1 = pygame.transform.scale(self.image1, (70, 55))
        self.image2 = pygame.transform.scale(self.image2, (70, 55))
        self.image = self.image1
        self.frame = 0
        self.x = 50
        self.y = GROUND_Y - 55
        self.speed = 5
        self.velocity_y = 0
        self.gravity = 0.5
        self.max_hp = 3
        self.hp = 3
        self.invincible = 0
        self.facing_right = True
        self.moving = False
        self.is_jumping = False
        self.width = 70
        self.height = 55
        self.dead = False
        self.respawn_timer = 0
        self.death_timer = 0
        
    def move_left(self):
        self.x -= self.speed
        self.facing_right = False
        self.moving = True
        
    def move_right(self):
        self.x += self.speed
        self.facing_right = True
        self.moving = True
    def jump(self):
        if not self.is_jumping:
            self.velocity_y = -12
            self.is_jumping = True
            
    def update(self, platforms):
        self.velocity_y += self.gravity
        self.y += self.velocity_y
        on_platform = False
        for platform in platforms:
            
              if (self.x + self.width > platform.x and
                self.x < platform.x + platform.image.get_width() and
                self.y + self.height >= platform.y and
                self.y + self.height <= platform.y + 20 and
                self.velocity_y >= 0):
                self.y = platform.y - self.height
                self.velocity_y = 0
                self.is_jumping = False
                on_platform = True
                
        if not on_platform:
            if level_data["has_ground"]:
                if self.y >= GROUND_Y - self.height:
                    self.y = GROUND_Y - self.height
                    self.velocity_y = 0
                    self.is_jumping = False
                    
        if self.invincible > 0:
            self.invincible -= 1
        if self.is_jumping:
            self.image = self.image1
        elif self.moving:
            self.frame += 1
            self.image = self.image1 if self.frame % 20 < 10 else self.image2
        else:
            self.image = self.image1
        if self.dead:
            self.y += self.velocity_y
            self.velocity_y += 0.5
            self.death_timer += 1
            if self.death_timer < 40:
                return
            self.dead = False
            self.death_timer = 0
            self.x = 50
            self.y = GROUND_Y - self.height
            self.velocity_y = 0
            self.invincible = 60
            
    def draw(self, screen):
        img = self.image
        if not self.facing_right:
            img = pygame.transform.flip(img, True, False)
        if self.invincible > 0 and self.invincible % 12 < 3:
            return
        screen.blit(img, (self.x, self.y))
#Враг
class Enemy:
    def __init__(self, x, y, platform=None, size=(70,70)):
        self.image1 = pygame.image.load(os.path.join(BASE_DIR, "enemy.png")).convert_alpha()
        self.image2 = pygame.image.load(os.path.join(BASE_DIR, "enemy2.png")).convert_alpha()
        self.image1 = pygame.transform.scale(self.image1, size)
        self.image2 = pygame.transform.scale(self.image2, size)
        self.image = self.image1
        self.frame = 0
        self.x = x
        self.y = y
        self.speed = 0.4
        self.direction = -1
        self.facing_right = False
        self.waiting = False
        self.platform = platform
        self.wait_time = 0
        
    def update(self):
        if self.waiting:
            self.wait_time += 1
            if self.wait_time >= 30:
                self.waiting = False
                self.wait_time = 0
                self.direction *= -1
            return
        self.x += self.speed * self.direction
        if self.x <= 0:
            self.x = 0
            self.waiting = True
        if self.x >= WIDTH - 70:
            self.x = WIDTH - 70
            self.waiting = True
        self.facing_right = self.direction == 1
        self.frame += 1
        self.image = self.image1 if self.frame % 120 < 60 else self.image2
        if self.platform:
            self.y = self.platform.y - self.image.get_height() + math.sin(self.frame * 0.05) * 2
        else:
            self.y = GROUND_Y - 70 + math.sin(self.frame * 0.05) * 2
        if self.platform:
            left_edge = self.platform.x
            right_edge = self.platform.x + self.platform.image.get_width() - 70
            if self.x <= left_edge:
                self.x = left_edge
                self.waiting = True
                
            if self.x >= right_edge:
                self.x = right_edge
                self.waiting = True
            
    def draw(self, screen):
        img = self.image
        if not self.facing_right:
            img = pygame.transform.flip(img, True, False)
        screen.blit(img, (self.x, self.y))
bg = Background()
enemies = [
    Enemy(600, 100),
    Enemy(200,100),
    ]
menu_bg = pygame.image.load(os.path.join(BASE_DIR, "menuu.jpg")).convert()
menu_bg = pygame.transform.scale(menu_bg, (WIDTH, HEIGHT))

options_bg = pygame.image.load(
    os.path.join(BASE_DIR, "options.jpg")
).convert()

options_bg = pygame.transform.scale(
    options_bg,
    (WIDTH, HEIGHT)
)

heart_full = pygame.image.load(os.path.join(BASE_DIR, "heart1.png")).convert_alpha()
heart_empty = pygame.image.load(os.path.join(BASE_DIR, "heart2.png")).convert_alpha()

heart_full = pygame.transform.scale(heart_full, (35, 35))
heart_empty = pygame.transform.scale(heart_empty, (35, 35))

game_over_img = pygame.image.load(os.path.join(BASE_DIR, "gameover.png")).convert_alpha()
game_over_img = pygame.transform.scale(game_over_img, (300, 100))

arrow_left = pygame.image.load(os.path.join(BASE_DIR, "arrow_left.png")).convert_alpha()
arrow_right = pygame.image.load(os.path.join(BASE_DIR, "arrow_right.png")).convert_alpha()

arrow_left = pygame.transform.scale(arrow_left, (40,40))
arrow_right = pygame.transform.scale(arrow_right, (40,40))

platform_img_long = pygame.image.load(os.path.join(BASE_DIR, "platform1.png")).convert_alpha()
platform_img_short = pygame.image.load(os.path.join(BASE_DIR, "platform2.png")).convert_alpha()
platform_img_tt = pygame.image.load(os.path.join(BASE_DIR, "platform1.png")).convert_alpha()
platform_img_long = pygame.transform.scale(platform_img_long, (180, 35))
platform_img_short = pygame.transform.scale(platform_img_short, (60, 35))
platform_img_tt = pygame.transform.scale(platform_img_tt, (270, 35))

item_img = pygame.image.load(os.path.join(BASE_DIR, "item.png")).convert_alpha()
item_img = pygame.transform.scale(item_img, (75, 55))

house_img = pygame.image.load(os.path.join(BASE_DIR, "home.png")).convert_alpha()
house_img = pygame.transform.scale(house_img, (200, 200))

menu_music = os.path.join(BASE_DIR, "menu_music.mp3")
game_music = os.path.join(BASE_DIR, "game_music.mp3")

win_music = os.path.join(BASE_DIR, "game_won.mp3")

fish_sound = pygame.mixer.Sound(os.path.join(BASE_DIR, "fish.wav"))
hit_sound = pygame.mixer.Sound(os.path.join(BASE_DIR, "hit.wav"))
water_sound = pygame.mixer.Sound(os.path.join(BASE_DIR, "water.wav"))
mya_sound = pygame.mixer.Sound(os.path.join(BASE_DIR, "mya.wav"))

empty_img = pygame.Surface(platform_img_long.get_size())
empty_img.set_alpha(0)

enemy_platform = Platform(150,165, platform_img_long)
enemy_platform2 = Platform(480,165, platform_img_long)
enemy_platform3 = Platform(540,291, platform_img_tt)
empty_img_small = pygame.Surface((100, 35))
empty_img_small.set_alpha(0)
empty_img_tiny = pygame.Surface((200, 10))
empty_img_tiny.set_alpha(0)
empty_img_smal = pygame.Surface((70, 35))
empty_img_smal.set_alpha(0)

levels = {
    1: {
        "background": bg.image1,
        "has_ground": True,
        "platforms": [
            Platform(150, 160, platform_img_long),
            Platform(205, 60, platform_img_short),
            Platform(480, 160, platform_img_long),
            Platform(540, 60, platform_img_short),
         ],
        "enemies": [
            Enemy(600, GROUND_Y - 70)
        ],
        "items": [
            Item(150, 110, item_img),
            Item(200, 110, item_img),
            Item(250, 110, item_img),
            Item(200, 10, item_img),
            Item(480, 110, item_img),
            Item(530, 110, item_img),
            Item(580, 110, item_img),
            Item(530, 10, item_img),
        ]
    },
    2: {
        "background": bg.image2,
        "has_ground": True,
        "platforms": [
            Platform(150,160, platform_img_long),
            Platform(205, 60, platform_img_short),
            Platform(480, 160, platform_img_long),
            Platform(540, 60, platform_img_short),
            ],
        "enemies": [
            Enemy(150, 160, enemy_platform, size=(50,50)),
            Enemy(150,160, enemy_platform2, size=(50,50)),
        ],
        "items": [
            Item(150, 110, item_img),
            Item(200, 110, item_img),
            Item(250, 110, item_img),
            Item(200, 10, item_img),
            Item(480, 110, item_img),
            Item(530, 110, item_img),
            Item(580, 110, item_img),
            Item(530, 10, item_img),
            Item(220, 240, item_img),
            Item(300, 240, item_img),
            Item(380, 240, item_img),
            Item(460, 240, item_img),
            Item(540, 240, item_img),
        ]
    },
    3: {
        "background": bg.image3,
        "has_ground": False,
        "platforms": [
            Platform(5,291, empty_img),
            Platform(340, 291, empty_img_small),
            Platform(610,291, empty_img)
        ],
        "spawn_x": 0,
        "spawn_y": 236,
        "enemies": [],
        "items": [
            Item(200, 180, item_img),
            Item(230, 160, item_img),
            Item(260, 180, item_img),
            Item(460, 180, item_img),
            Item(490, 160, item_img),
            Item(520, 180, item_img)
        ]
    },
    4: {
        "background": bg.image4,
        "has_ground": False,
        "platforms": [
            Platform(-70,291, empty_img),
            Platform(280, 291, empty_img),
            Platform(410,260, empty_img),
            Platform(410,240, empty_img),
            Platform(410,220, empty_img),
            Platform(410,208, empty_img),
            Platform(500,208, empty_img),
            Platform(650,208, empty_img)
        ],
        "spawn_x": 0,
        "spawn_y": 236,
        "enemies": [],
        "items": [
            Item(120, 180, item_img),
            Item(150, 160, item_img),
            Item(180, 180, item_img)
        ]
    },
    5: {
        "background": bg.image5,
        "has_ground": False,
        "platforms": [
            Platform(10, 205, empty_img),
            Platform(170, 205, empty_img),
            Platform(270, 205, empty_img),
            Platform(340, 205, empty_img),
            Platform(500, 291, empty_img),
            Platform(650, 291, empty_img),
        ],
        "enemies": [
            Enemy(330, 291, enemy_platform3, size=(65,65)),
        ],
        "spawn_x": 10,
        "spawn_y": 150,
        "items": [
            Item(120, 120, item_img),
            Item(200, 120, item_img),
            Item(280, 120, item_img),
            Item(360, 120, item_img)
        ]
    },
    6: {
        "background": bg.image6,
        "has_ground": False,
        "platforms": [
            Platform(-80, 291, empty_img),
            Platform(130, 291, empty_img),
            Platform(130, 270, empty_img),
            Platform(130, 240, empty_img),
            Platform(130, 205, empty_img),
            Platform(280, 205, empty_img_small),
            Platform(560, 205, empty_img_smal),
            Platform(560, 225, empty_img_small),
            Platform(560, 255, empty_img_small),
            Platform(560, 275, empty_img_small),
            Platform(680, 291, empty_img),
        ],
        "spawn_x": 0,
        "spawn_y": 236,
        "enemies": [],
        "items": [
            Item(120, 120, item_img),
            Item(200, 120, item_img),
            Item(280, 120, item_img),
            Item(360, 120, item_img)
        ]
    },
    7: {
        "background": bg.image7,
        "has_ground": False,
        "platforms": [
            Platform(-80, 291, empty_img),
            Platform(130, 210, empty_img_small),
            Platform(160, 230, empty_img_small),
            Platform(160, 250, empty_img_small),
            Platform(160, 270, empty_img_small),
            Platform(180, 291, empty_img),
            Platform(420, 210, empty_img_small),
            Platform(420, 230, empty_img_small),
            Platform(420, 250, empty_img_small),
            Platform(420, 270, empty_img),
            Platform(540, 210, empty_img),
            Platform(680, 210, empty_img)
        ],
        "spawn_x": 0,
        "spawn_y": 236,
        "enemies": [],
        "items": [
            Item(260, 240, item_img),
            Item(300, 240, item_img),
            Item(340, 240, item_img)
        ]
    },
    8: {
        "background": bg.image8,
        "has_ground": False,
        "platforms": [
            Platform(-80, 210, empty_img),
            Platform(300, 291, empty_img),
            Platform(380, 291, empty_img),
            Platform(450, 291, empty_img),
            Platform(550, 291, empty_img),
            Platform(680, 291, empty_img),
            Platform(420, 210, empty_img_tiny)
            
        ],
        "spawn_x": 0,
        "spawn_y": 155,
        "enemies": [],
        "items": [
            Item(130, 160, item_img),
            Item(160, 170, item_img),
            Item(190, 180, item_img),
            Item(410, 140, item_img),
            Item(470, 140, item_img),
            Item(530, 140, item_img),
            Item(590, 140, item_img),
        ]
    },
    9: {
        "background": bg.image9,
        "has_ground": True,
        "spawn_x": 0,
        "spawn_y": 236,
        "house_x": 570,
        "house_y": 95,
        "platforms": [],
        "enemies": [
            Enemy(600, GROUND_Y - 70)
            ],
        "items": []
    },
    
}
            
current_level = 1
level_data = levels[current_level]
selected_cat = 0
player = Player(selected_cat)
score = 0
deaths = 0
font = pygame.font.Font(os.path.join(BASE_DIR, "PressStart2p.ttf"), 20)
game_over = False
game_state = "menu"
paused = False
game_won = False

play_button = pygame.Rect(290, 120, 220, 60)
options_button = pygame.Rect(290, 200, 220, 60)
exit_win_button = pygame.Rect(290, 380, 220, 50)

restart_button = pygame.Rect(260, 300, 280, 50)

left_btn = pygame.Rect(220, 170, 60, 60)
right_btn = pygame.Rect(520, 170, 60, 60)
back_btn = pygame.Rect(305, 300, 200, 50)

pause_button = pygame.Rect(WIDTH - 50, 0, 40, 40)
win_scale = 10
pygame.mixer.music.load(menu_music)
pygame.mixer.music.play(-1)

while True:
    clock.tick(60)

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:

            if event.key == pygame.K_ESCAPE:
                paused = not paused

            if event.key == pygame.K_SPACE and not paused:
                player.jump()

            if event.key == pygame.K_r and game_over:
                player = Player(selected_cat)
                enemy = Enemy(600, GROUND_Y - 70)
                current_level = 1
                level_data = levels[current_level]

                score = 0
                for level in levels.values():
                    for item in level["items"]:
                        item.collected = False

                game_over = False

        if event.type == pygame.MOUSEBUTTONDOWN:

            mouse_pos = event.pos

            if game_state == "options":
                if left_btn.collidepoint(mouse_pos):
                    selected_cat -= 1

                    if selected_cat < 0:
                        selected_cat = 2

                elif right_btn.collidepoint(mouse_pos):
                    selected_cat += 1

                    if selected_cat > 2:
                        selected_cat = 0

                if back_btn.collidepoint(mouse_pos):
                    player = Player(selected_cat)
                    game_state = "menu"

            if pause_button.collidepoint(mouse_pos):
                paused = not paused


            if game_won:
                if restart_button.collidepoint(mouse_pos):

                    pygame.mixer.music.stop()
                    pygame.mixer.music.load(menu_music)
                    pygame.mixer.music.play(-1)
                    
                    current_level = 1
                    win_scale = 10
                    level_data = levels[current_level]

                    player = Player(selected_cat)

                    score = 0
                    deaths = 0
                    game_won = False
                    game_over = False

                    win_scale = 10

                    game_state = "menu"

                    for level in levels.values():
                        for item in level["items"]:
                            item.collected = False

                if exit_win_button.collidepoint(mouse_pos):
                    pygame.quit()
                    sys.exit()


            if game_state == "menu":
                if play_button.collidepoint(mouse_pos):
                    
                    pygame.mixer.music.stop()
                    pygame.mixer.music.load(game_music)
                    player = Player(selected_cat)
                    pygame.mixer.music.play(-1)
                    game_state = "game"
                    
                if exit_win_button.collidepoint(mouse_pos):
                    pygame.quit()
                    sys.exit()

                elif options_button.collidepoint(mouse_pos):
                    game_state = "options"

    if game_state == "game" and not game_over and not paused and not game_won:
        player.moving = False
        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT]:
            player.move_left()
        elif keys[pygame.K_RIGHT]:
            player.move_right()

        player_rect = pygame.Rect(player.x, player.y, player.width, player.height)
        for platform in level_data["platforms"]:
            platform_rect = pygame.Rect(
                platform.x,
                platform.y,
                platform.image.get_width(),
                platform.image.get_height()
            )
            if player_rect.colliderect(platform_rect):
                if keys[pygame.K_LEFT]:
                    player.x += player.speed
                elif keys[pygame.K_RIGHT]:
                    player.x -= player.speed

        player.update(level_data["platforms"])

        for enemy in level_data["enemies"]:
            enemy.update()

        player_rect = pygame.Rect(player.x + 10, player.y + 5, 50, 45)
        if current_level == 9 and player.x > 500:
            house_rect = pygame.Rect(
                level_data["house_x"],
                level_data["house_y"],
                160,
                160
            )
            if player_rect.colliderect(house_rect):
                if not game_won:
                    pygame.mixer.music.stop()
                    pygame.mixer.music.load(win_music)
                    pygame.mixer.music.play(0)
                game_won = True
            

        if player.y > HEIGHT and player.invincible == 0:
            if current_level == 3:
                water_sound.play()
                mya_sound.play()
            else:
                mya_sound.play()
            player.hp -= 1
            deaths += 1
            player.x = level_data["spawn_x"]
            player.y = level_data["spawn_y"] - 5
            player.velocity_y = 0
            player.is_jumping = False
            player.dead = False
            player.moving = False

            player.invincible = 60

        for enemy in level_data["enemies"]:
            enemy_rect = pygame.Rect(enemy.x + 10, enemy.y + 5, 50, 60)

            if player_rect.colliderect(enemy_rect):
                if player.invincible == 0 and not player.dead:
                    hit_sound.play()
                    player.hp -= 1
                    player.dead = True
                    player.velocity_y = -8
                    player.invincible = 45

        if player.hp <= 0:
            game_over = True

        for item in level_data["items"]:
            if not item.collected and player_rect.colliderect(item.rect):
                item.collected = True
                score += 1
                fish_sound.play()

        for item in level_data["items"]:
            item.update()

        if player.x >= WIDTH - 70:
            if current_level < 9:
                current_level += 1
                level_data = levels[current_level]
                player.x = 0
                if current_level == 5 or current_level == 8:
                    player.y = 205 - player.height
                else:
                    player.y = GROUND_Y - player.height

    if game_state == "menu":
        screen.blit(menu_bg, (0, 0))

    elif game_state == "options":
        screen.blit(options_bg, (0,0))

        shadow = font.render("CHOOSE YOUR CAT!", True, (0, 0, 0))
        text = font.render("CHOOSE YOUR CAT!", True, (255, 255, 255))

        text_rect = text.get_rect(center=(410,70))
        screen.blit(shadow, (text_rect.x + 2, text_rect.y + 2))
        screen.blit(text, text_rect)

        preview = Player(selected_cat)
        skin = cat_skins[selected_cat][0]
        preview_img = pygame.image.load(skin)
        preview_img = pygame.transform.scale(preview_img, (100, 80))
        screen.blit(preview_img, (345, 150))

        screen.blit(arrow_right, (left_btn.x + 10, left_btn.y + 10))
        screen.blit(arrow_left, (right_btn.x + 10, right_btn.y + 10))

        pygame.draw.rect(screen, (214, 214, 214), back_btn, border_radius=15)

        pygame.draw.rect(screen, (0,0,0), back_btn, 3, border_radius=12)

        back_text = font.render("BACK", True, (0,0,0))

        back_rect = back_text.get_rect(center=back_btn.center)

        screen.blit(back_text, back_rect)

    elif game_state == "game":
        screen.blit(level_data["background"], (0, 0))
    
        for platform in level_data["platforms"]:
            platform.draw(screen)

        for item in level_data["items"]:
            item.draw(screen)

        for enemy in level_data["enemies"]:
            enemy.draw(screen)

        if current_level == 9:
            screen.blit(house_img,
                        (level_data["house_x"],
                         level_data["house_y"]))
                         

        player.draw(screen)

        for i in range(player.max_hp):
            if i < player.hp:
                screen.blit(heart_full, (10 + i * 35, 10))
            else:
                screen.blit(heart_empty, (10 + i * 35, 10))

        score_text = font.render(f"Score: {score}", True, (255, 255, 255))
        rect = score_text.get_rect(center=(WIDTH // 2, 15))
        screen.blit(score_text, rect)

        if game_over:
            
            rect = game_over_img.get_rect(center=(WIDTH // 2, HEIGHT // 2))
            screen.blit(game_over_img, rect)
            shadow = font.render("Press R to Restart", True, (0,0,0))
            text = font.render("Press R to Restart", True, (255, 255, 255))
            text_rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 60))
            screen.blit(shadow, (text_rect.x + 2, text_rect.y + 2))
            screen.blit(text, text_rect)

        if game_over:
            rect = game_over_img.get_rect(center=(WIDTH // 2, HEIGHT // 2))
            screen.blit(game_over_img, rect)

        if game_won:
            overlay = pygame.Surface((WIDTH, HEIGHT))
            overlay.set_alpha(170)
            overlay.fill((0,0,0))
            screen.blit(overlay, (0,0))

            if win_scale < 60:
                win_scale += 2

            big_font = pygame.font.Font(
                os.path.join(BASE_DIR, "PressStart2p.ttf"),
                win_scale
            )

            win_text = big_font.render("YOU WIN!", True, (255,255,255))

            win_rect = win_text.get_rect(center=(WIDTH//2, 100))

            screen.blit(win_text, win_rect)

            panel = pygame.Rect(170, 160, 460, 220)

            pygame.draw.rect(screen,(91,141,176),panel,border_radius=20)

            pygame.draw.rect(screen,(0,0,0),panel,4,border_radius=20)

            score_text = font.render(f"Score: {score}",True,(255,255,255))

            screen.blit(score_text, (260, 210))

            death_text = font.render(f"Deaths: {deaths}",True, (255,255,255))

            screen.blit(death_text, (260, 240))

            pygame.draw.rect(screen,(214,214,214),restart_button,border_radius=10)

            pygame.draw.rect(screen,(0,0,0),restart_button,2,border_radius=10)

            restart_text = font.render("RESTART",True,(0,0,0))

            restart_rect = restart_text.get_rect(center=restart_button.center)

            screen.blit(restart_text, restart_rect)

    if paused:
        overlay = pygame.Surface((WIDTH, HEIGHT))
        overlay.set_alpha(120)
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))

        pause_text = font.render("PAUSED", True, (255, 255, 255))
        rect = pause_text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        screen.blit(pause_text, rect)


    pygame.draw.rect(screen, (255, 255, 255), (pause_button.x + 10, pause_button.y + 8, 5, 24))

    pygame.draw.rect(screen, (255, 255, 255), (pause_button.x + 22, pause_button.y + 8, 5, 24))


    pygame.display.flip()   
